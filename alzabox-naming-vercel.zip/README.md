
# AlzaBox naming MVP – Vercel projekt

Tento balíček obsahuje:
- React frontend
- Vercel backend endpoint `/api/mapy-lookup`
- bezpečné čtení `MAPY_API_KEY` z Environment Variables

## Jak to nasadit na Vercel

1. Vytvoř GitHub repository.
2. Nahraj do něj všechny soubory z tohoto ZIPu.
3. Ve Vercelu dej **Import Git Repository** a vyber ten repository.
4. V projektu otevři **Environment Variables**.
5. Přidej proměnnou:

```txt
MAPY_API_KEY=tvuj_novy_mapy_klic
```

6. Dej **Redeploy**.

## Co máš po nasazení vidět

Když vše funguje, v aplikaci po kliknutí na **Generovat název** uvidíš:

```txt
Zdroj: Mapy.cz API
```

Když tam bude chyba typu `Chybí MAPY_API_KEY`, není nastavený API klíč ve Vercelu.

## Poznámka

Mapy.com dokumentace uvádí, že Geocoding API podporuje geocoding, suggest i reverse geocoding; reverse geocoding vrací regionální entity podle `lon` a `lat`. Endpoint v tomto MVP je připravený podle aktuální dokumentace, ale pokud Mapy.com změní přesný tvar odpovědi, bude potřeba drobně upravit normalizaci dat v `api/mapy-lookup.js`.
