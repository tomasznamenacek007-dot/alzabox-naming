
import React, { useState } from "react";
import { MapPin, Sparkles, Copy, Check, FileText, Save, Database, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

const POI_PRIORITY = [
  "Kaufland", "Tesco", "Penny", "Albert", "Billa", "Globus", "OMV",
  "OC", "NC", "Hlavní nádraží", "nádraží", "metro", "KFC",
  "Havaj", "restaurace", "hospoda", "kavárna"
];

const PRAGUE_DISTRICTS = {
  Křeslice: "P10", Nusle: "P4", Bohnice: "P8", Žižkov: "P3",
  Evropská: "P6", Letňany: "P18", Kbely: "P19", Zálesí: "P4",
  Dejvice: "P6", Strahov: "P6", Modřany: "P12", Suchdol: "P6",
  Eden: "P10", Střelničná: "P8", Jarov: "P9", Skalka: "P10",
  Vysočanská: "P9", Vypich: "P6", Stodůlky: "P13", Zbraslav: "P16",
  Chodov: "P11", Prosek: "P9", Libuš: "P12", Čakovice: "P18",
  Smíchov: "P5"
};

const DEMO_FALLBACKS = [
  {
    lat: "50.027472", lng: "14.559194", city: "Praha", district: "Křeslice",
    street: "K Fantovu mlýnu", pois: ["Penny"], preferredName: "P10 - Křeslice - K Fantovu mlýnu"
  },
  {
    lat: "50.061160", lng: "14.427740", city: "Praha", district: "Nusle",
    street: "5. května", pois: ["OMV", "Kongresové centrum"], preferredName: "P4 - Nusle (OMV u Kongresového centra)"
  },
  {
    lat: "49.277900", lng: "16.998500", city: "Vyškov", district: "Lípová",
    street: "Lípová", pois: ["Havaj"], preferredName: "Vyškov - Lípová (Havaj)"
  },
  {
    lat: "49.052900", lng: "14.441500", city: "Hluboká nad Vltavou", district: "Nad Pilou",
    street: "Nad Pilou", pois: [], preferredName: "Hluboká nad Vltavou - Nad Pilou"
  },
  {
    lat: "49.589304", lng: "17.348853", city: "Velká Bystřice", district: "",
    street: "", pois: ["Penny"], preferredName: "Velká Bystřice (Penny)"
  }
];

function norm(value) {
  return String(value || "").trim().replace(",", ".");
}

function toNumber(value) {
  const parsed = Number(norm(value));
  return Number.isFinite(parsed) ? parsed : null;
}

function coordinatesMatch(aLat, aLng, bLat, bLng) {
  const lat1 = toNumber(aLat), lng1 = toNumber(aLng), lat2 = toNumber(bLat), lng2 = toNumber(bLng);
  if ([lat1, lng1, lat2, lng2].some((v) => v === null)) return false;
  return Math.abs(lat1 - lat2) < 0.00025 && Math.abs(lng1 - lng2) < 0.00025;
}

function findFallback(lat, lng) {
  return DEMO_FALLBACKS.find((item) =>
    coordinatesMatch(item.lat, item.lng, lat, lng) || coordinatesMatch(item.lat, item.lng, lng, lat)
  );
}

function chooseBestPoi(pois = []) {
  if (!pois.length) return null;
  return [...pois].sort((a, b) => {
    const ai = POI_PRIORITY.findIndex((p) => String(a).toLowerCase().includes(p.toLowerCase()));
    const bi = POI_PRIORITY.findIndex((p) => String(b).toLowerCase().includes(p.toLowerCase()));
    return (ai === -1 ? 999 : ai) - (bi === -1 ? 999 : bi);
  })[0];
}

function pragueCode(city, district) {
  const direct = `${city} ${district}`.match(/Praha\s*(\d+)/i) || `${city} ${district}`.match(/P\s*(\d+)/i);
  if (direct) return `P${direct[1]}`;
  return PRAGUE_DISTRICTS[district] || "P?";
}

function buildName(data) {
  if (data.preferredName) return data.preferredName;

  const city = data.city || "Neznámé město";
  const district = data.district || "";
  const street = data.street || "";
  const poi = chooseBestPoi(data.pois || []);
  const isPrague = city.toLowerCase().includes("praha");

  if (isPrague) {
    const code = pragueCode(city, district);
    if (poi && poi !== street && poi !== district) return `${code} - ${district || street} (${poi})`;
    if (district && street && district !== street) return `${code} - ${district} - ${street}`;
    return `${code} - ${district || street || "ověřit lokalitu"}`;
  }

  if (poi && !street && !district) return `${city} (${poi})`;
  if (poi && poi !== street && poi !== district) return `${city} - ${street || district} (${poi})`;
  return `${city} - ${street || district || "ověřit lokalitu"}`;
}

async function lookup(lat, lng) {
  const response = await fetch(`/api/mapy-lookup?lat=${encodeURIComponent(lat)}&lng=${encodeURIComponent(lng)}`);
  const json = await response.json();

  if (!response.ok || json.error) {
    const fallback = findFallback(lat, lng);
    if (fallback) return { ...fallback, source: "Demo fallback" };
    throw new Error(json.error || "Lookup selhal.");
  }

  const fallback = findFallback(lat, lng);
  return {
    city: json.city || fallback?.city || "Neznámé město",
    district: json.district || fallback?.district || "",
    street: json.street || fallback?.street || "",
    pois: json.pois?.length ? json.pois : (fallback?.pois || []),
    preferredName: fallback?.preferredName,
    source: json.source || "Mapy.cz API"
  };
}

function generateText(data, lat, lng) {
  const name = buildName(data);
  const poi = chooseBestPoi(data.pois || []);
  const location = [data.city, data.district || data.street].filter(Boolean).join(" – ");
  return {
    recommendedName: name,
    variants: Array.from(new Set([
      name,
      data.city && data.street ? `${data.city} - ${data.street}` : null,
      data.city && poi ? `${data.city} (${poi})` : null
    ].filter(Boolean))),
    shortDescription: `Výdejní box se nachází v lokalitě ${location || "ověřit lokalitu"}${poi ? `, poblíž ${poi}` : ""}.`,
    webDescription: `Výdejní box najdete v lokalitě ${location || "ověřit lokalitu"}${poi ? `, u orientačního bodu ${poi}` : ""}. Název je navržen tak, aby zákazník na první pohled poznal, kde je box umístěný.`,
    internalNote: `Zdroj: ${data.source}. GPS: ${lat}, ${lng}. Před publikací ověřit vstup, přesné umístění a nejlepší orientační bod.`,
    source: data.source
  };
}

export default function App() {
  const [lat, setLat] = useState("50.027472");
  const [lng, setLng] = useState("14.559194");
  const [output, setOutput] = useState(null);
  const [approved, setApproved] = useState([]);
  const [status, setStatus] = useState("Připraveno");
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  async function generate() {
    setError("");
    setOutput(null);
    setStatus("Hledám přes Mapy.cz...");
    try {
      const data = await lookup(lat, lng);
      setOutput(generateText(data, lat, lng));
      setStatus(data.source);
    } catch (err) {
      setError(err.message);
      setStatus("Chyba");
    }
  }

  async function copy() {
    if (!output) return;
    await navigator.clipboard.writeText(`Název: ${output.recommendedName}\n\n${output.shortDescription}\n\n${output.webDescription}\n\n${output.internalNote}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  }

  function approve() {
    if (!output) return;
    setApproved((items) => [{ id: Date.now(), name: output.recommendedName, lat, lng, source: output.source, time: new Date().toLocaleString("cs-CZ") }, ...items]);
  }

  return (
    <main className="app">
      <motion.header initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="hero">
        <div>
          <div className="badge"><Sparkles size={16}/> MVP naming engine</div>
          <h1>Generátor názvů boxů z GPS</h1>
          <p>Zadej GPS, aplikace zavolá backend s Mapy.cz API a navrhne název podle pravidel.</p>
        </div>
        <div className="status">
          <span>Stav</span>
          <strong>{status}</strong>
          <small>API klíč je schovaný na backendu.</small>
        </div>
      </motion.header>

      <section className="grid">
        <div className="card inputs">
          <h2><MapPin size={20}/> Vstupní údaje</h2>
          <div className="row">
            <label>Latitude<input value={lat} onChange={(e)=>setLat(e.target.value)} /></label>
            <label>Longitude<input value={lng} onChange={(e)=>setLng(e.target.value)} /></label>
          </div>
          <button className="primary" onClick={generate}><Sparkles size={16}/> Generovat název</button>
          {error && <div className="error"><AlertCircle size={16}/>{error}</div>}

          <h3>Testovací GPS</h3>
          <div className="examples">
            {DEMO_FALLBACKS.map((item) => (
              <button key={item.preferredName} onClick={() => { setLat(item.lat); setLng(item.lng); setOutput(null); }}>
                <strong>{item.preferredName}</strong>
                <span>{item.lat}, {item.lng}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="card output">
          <div className="toolbar">
            <h2><FileText size={20}/> Výstup</h2>
            <div>
              <button onClick={approve} disabled={!output}><Save size={16}/> Potvrdit</button>
              <button onClick={copy} disabled={!output}>{copied ? <Check size={16}/> : <Copy size={16}/>} {copied ? "Zkopírováno" : "Kopírovat"}</button>
            </div>
          </div>

          {output ? (
            <div className="result">
              <p className="label">Doporučený název</p>
              <h2>{output.recommendedName}</h2>
              <p className="source">Zdroj: {output.source}</p>
              <div className="variants">
                {output.variants.map((v) => <div key={v}>{v}</div>)}
              </div>
              <h3>Krátký popis</h3>
              <p>{output.shortDescription}</p>
              <h3>Popis na web</h3>
              <p>{output.webDescription}</p>
              <h3>Interní poznámka</h3>
              <p>{output.internalNote}</p>
            </div>
          ) : (
            <div className="empty">Zadej GPS a klikni na Generovat název.</div>
          )}
        </div>
      </section>

      {approved.length > 0 && (
        <section className="card">
          <h2><Check size={20}/> Potvrzené názvy</h2>
          {approved.map((item) => (
            <div className="approved" key={item.id}>
              <strong>{item.name}</strong>
              <span>{item.lat}, {item.lng} · {item.source} · {item.time}</span>
            </div>
          ))}
        </section>
      )}

      <section className="card note">
        <h2><Database size={20}/> Poznámka k Mapy.cz</h2>
        <p>Backend endpoint je připravený v <code>/api/mapy-lookup.js</code>. Po vložení environment variable <code>MAPY_API_KEY</code> na Vercelu se začne používat reálné Mapy.cz API.</p>
      </section>
    </main>
  );
}
